#include<iostream>
#include<math.h>
#include<conio.h>
#include<string.h>
using namespace std;
int main(){
	
	float num1, num2, operation;
	int option = 0;
	int back;
	 cout << "\t Opciones\n";
	 cout << " 1 - Suma\n";
	 cout << " 2 - Resta\n";
	 cout << " 3 - Multiplicacion\n";
	 cout << " 4 - Division\n";
	 cout << " 5 - Potencia\n";
	 cout << " 6 - Raiz\n";
	 cout << "\n";
	 cout << " Cualquier tecla para salir";
	 cout << "\n";
	 cin >> option;
	
switch(option)
{
    case 1: cout << " Usted ha seleccionado la opcion 1, suma \n";
    cout << "\n";
    cout << " Ingrese primer digito: ";
	 	cin >> num1;
	 	cout<<"\n";
	 	cout << " Ingrese segundo digito: ";
	 	cin >> num2;
	 	cout<<"\n";
	 	operation = num1 + num2;
	 	cout<<" El resultado de la suma es: " <<operation<<endl;
	 	
	 	cout<<" Seleccione 0 para regresar al menu ";
	 	cin>>back;
	 	cout<<"\n";
    	while(back != 0)
    	{
        	cout << " Seleccione 0 para regresar al menu ";
        	cin >> back;
    	}
    	return main();
    break;
    
    case 2: cout << " Usted ha seleccionado la opcion 2, resta \n";
    cout << " Ingrese primer digito: \n";
	 	cin >> num1;
	 	cout<<"\n";
	 	cout << " Ingrese segundo digito: \n";
	 	cin >> num2;
	 	cout<<"\n";
	 	operation = num1 - num2;
	 	cout<<" El resultado de la resta es: " <<operation<<endl;
	 	
	 	cout<<" Seleccione 0 para regresar al menu ";
	 	cin>>back;
	 	cout<<"\n";
    	while(back != 0)
    	{
        	cout << " Seleccione 0 para regresar al menu ";
        	cin >> back;
    	}
    	return main();
    break;
    
    case 3: cout << " Usted ha seleccionado la opcion 3, multiplicacion \n";
    cout << " Ingrese primer digito: ";
	 	cin >> num1;
	 	cout<<"\n";
	 	cout << " Ingrese segundo digito: ";
	 	cin >> num2;
	 	cout<<"\n";
	 	operation = num1 * num2;
	 	cout<<" El resultado de la multiplicacion es: " <<operation<<endl;
	 	
	 	cout<<" Seleccione 0 para regresar al menu ";
	 	cin>>back;
	 	cout<<"\n";
    	while(back != 0)
    	{
        	cout << " Seleccione 0 para regresar al menu ";
        	cin >> back;
    	}
    	return main();
	break;
	
    case 4: cout << " Usted ha seleccionado la opcion 4, division \n";
    cout << " Ingrese primer digito: ";
	 	cin >> num1;
	 	cout<<"\n";
	 	cout << " Ingrese segundo digito: ";
	 	cin >> num2;
	 	cout<<"\n";
	 	operation = num1 / num2;
	 	cout<<" El resultado de la division es: " <<operation<<endl;
	 	
	 	cout<<" Seleccione 0 para regresar al menu ";
	 	cin>>back;
	 	cout<<"\n";
    	while(back != 0)
    	{
        	cout << " Seleccione 0 para regresar al menu ";
        	cin >> back;
    	}
    	return main();
    break;
    
    case 5: cout << " Usted ha seleccionado la opcion 5, potencia \n";
    cout << " Ingrese primer digito: ";
	 	cin >> num1;
	 	cout<<"\n";
	 	cout << " Ingrese segundo digito: ";
	 	cin >> num2;
	 	cout<<"\n";
	 	operation = pow(num1, num2);
	 	cout<<" El resultado de la potencia es: " <<operation<<endl;
	 	
	 	cout<<" Seleccione 0 para regresar al menu ";
	 	cin>>back;
	 	cout<<"\n";
    	while(back != 0)
    	{
        	cout << "Seleccione 0 para regresar al menu ";
        	cin >> back;
    	}
    	return main();
    break;
    
    case 6: cout << " Usted ha seleccionado la opcion 6, raiz";
    cout << "\n";
    cout << " Ingrese primer digito: ";
	 	cin >> num1;
	 	cout<<"\n";
	 	cout << " Ingrese segundo digito: ";
	 	cin >> num2;
	 	cout<<"\n";
	 	operation = pow(num1,(1/num2));
	 	cout<<" El resultado del radical es: " <<operation<<endl;
	 	
	 	cout<<" Seleccione 0 para regresar al menu ";
	 	cin>>back;
	 	cout<<"\n";
    	while(back != 0)
    	{
        	cout << " Seleccione 0 para regresar al menu ";
        	cin >> back;
    	}
    	return main();
    break;
    
    default: return 0;
	}
}

